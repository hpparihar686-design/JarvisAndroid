package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var log: TextView
    private lateinit var input: EditText
    private lateinit var keyInput: EditText
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var wakeMode = false
    private val client = OkHttpClient.Builder()
        .callTimeout(35, TimeUnit.SECONDS).build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
        addLine("JARVIS", "Online. API key add karke AI chat use kar sakte hain. Voice features ke liye microphone permission dein.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(0xFF071521.toInt())
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 28f; gravity = Gravity.CENTER
            setTextColor(0xFF42D7FF.toInt())
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 64))
        val subtitle = TextView(this).apply {
            text = "Personal voice assistant • Android"
            gravity = Gravity.CENTER; textSize = 13f
            setTextColor(0xFFB5D6E5.toInt())
        }
        root.addView(subtitle)
        keyInput = EditText(this).apply {
            hint = "OpenAI API key (sirf apni key)"
            setSingleLine(true); textSize = 14f
            setTextColor(-1); setHintTextColor(0xFF8CA8B8.toInt())
            setBackgroundColor(0xFF132B3B.toInt())
            setPadding(12, 8, 12, 8)
            inputType =  textInputTypePassword()
        }
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        keyInput.setText(prefs.getString("api_key", ""))
        root.addView(keyInput, LinearLayout.LayoutParams(-1, 52))
        val save = makeButton("Save API key") {
            prefs.edit().putString("api_key", keyInput.text.toString().trim()).apply()
            addLine("JARVIS", "API key is device par save ho gayi. Is APK ko kisi aur ke saath share na karein.")
        }
        root.addView(save)
        log = TextView(this).apply {
            textSize = 15f; setTextColor(0xFFE4F4FA.toInt())
            setPadding(8, 12, 8, 12)
        }
        val scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        input = EditText(this).apply {
            hint = "Type a command..."
            setTextColor(-1); setHintTextColor(0xFF8CA8B8.toInt())
            setBackgroundColor(0xFF132B3B.toInt()); setPadding(12, 8, 12, 8)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, 52))
        val send = makeButton("Send command") { val s = input.text.toString().trim(); if (s.isNotEmpty()) { input.setText(""); handleCommand(s) } }
        root.addView(send)
        root.addView(makeButton("Speak command") { startListening(false) })
        root.addView(makeButton("Start 'Hey Jarvis' mode (app open)") {
            wakeMode = true
            addLine("JARVIS", "Wake mode on. App ko foreground mein khula rakhein aur 'Hey Jarvis' boliye.")
            startListening(true)
        })
        root.addView(makeButton("Stop listening") {
            wakeMode = false
            try { recognizer?.stopListening(); recognizer?.cancel() } catch (_: Exception) {}
            addLine("JARVIS", "Listening stopped.")
        })
        setContentView(root)
    }

    private fun textInputType(): Int = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun addLine(who: String, message: String) {
        runOnUiThread {
            log.append("\n$who: $message\n")
        }
    }

    private fun startListening(isWake: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addLine("JARVIS", "Is device par speech recognition available nahi hai."); return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            addLine("JARVIS", "Microphone permission allow karein."); return
        }
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                if (wakeMode && isWake) log.postDelayed({ if (wakeMode) startListening(true) }, 900)
            }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) {
                    addLine("YOU", spoken)
                    if (isWake) {
                        if (spoken.lowercase(Locale.ROOT).contains("hey jarvis") ||
                            spoken.lowercase(Locale.ROOT).contains("hello jarvis")) {
                            wakeMode = false
                            addLine("JARVIS", "Yes. Ab apni command boliye.")
                            speak("Yes. I am listening.")
                            startListening(false)
                        } else if (wakeMode) {
                            startListening(true)
                        }
                    } else handleCommand(spoken)
                } else if (wakeMode && isWake) startListening(true)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (isWake) "Say Hey Jarvis" else "Speak your command")
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        addLine("YOU", raw)
        val s = raw.lowercase(Locale.ROOT).trim()
        when {
            s.contains("open youtube") || s.contains("youtube kholo") -> openUrl("https://www.youtube.com")
            s.contains("open whatsapp") || s.contains("whatsapp kholo") -> launchPackage("com.whatsapp")
            s.contains("open camera") || s.contains("camera kholo") -> launchIntent(Intent("android.media.action.IMAGE_CAPTURE"))
            s.contains("open settings") || s.contains("settings kholo") -> launchIntent(Intent(android.provider.Settings.ACTION_SETTINGS))
            s.startsWith("search ") || s.startsWith("google ") || s.startsWith("search karo ") ->
                openUrl("https://www.google.com/search?q=" + android.net.Uri.encode(raw.substringAfter(" ", raw)))
            s.startsWith("call ") || s.startsWith("dial ") || s.startsWith("number ") -> {
                val number = raw.filter { it.isDigit() || it == '+' }
                if (number.length >= 5) launchIntent(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:$number")))
                else addLine("JARVIS", "Number samajh nahi aaya. Example: call 9876543210")
            }
            s.contains("set alarm") || s.contains("alarm lagao") -> {
                val i = Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
                    .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "JARVIS alarm")
                launchIntent(i)
            }
            s == "stop" || s == "stop speaking" -> { if (::tts.isInitialized) tts.stop() }
            else -> askCloud(raw)
        }
    }

    private fun launchPackage(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else addLine("JARVIS", "Yeh app installed nahi mil raha.")
    }

    private fun launchIntent(i: Intent) {
        try { startActivity(i) } catch (_: Exception) { addLine("JARVIS", "Is action ke liye compatible app nahi mila.") }
    }

    private fun openUrl(url: String) = launchIntent(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))

    private fun askCloud(prompt: String) {
        val key = keyInput.text.toString().trim()
        if (key.isBlank()) {
            addLine("JARVIS", "AI jawab ke liye apni API key add karein. Local phone commands bina key ke chalti hain.")
            return
        }
        addLine("JARVIS", "Soch raha hoon...")
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content",
                "You are JARVIS, a helpful Android voice assistant. Reply concisely in the user's language. You cannot directly control the phone; the app handles only its listed safe intents. Never claim an action happened unless the app did it. Ask confirmation for sensitive actions."))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject().put("model", "gpt-4o-mini").put("messages", messages)
            .put("temperature", 0.6).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val req = Request.Builder().url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $key")
            .post(body).build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                addLine("JARVIS", "Network error: ${e.localizedMessage ?: "connection failed"}")
            }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val text = it.body?.string().orEmpty()
                    if (!it.isSuccessful) {
                        addLine("JARVIS", "AI request failed (${it.code}). API key, billing aur internet check karein.")
                        return
                    }
                    try {
                        val answer = JSONObject(text).getJSONArray("choices")
                            .getJSONObject(0).getJSONObject("message").getString("content")
                        addLine("JARVIS", answer)
                        speak(answer)
                    } catch (_: Exception) { addLine("JARVIS", "AI response read nahi ho paya.") }
                }
            }
        })
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        wakeMode = false
        try { recognizer?.destroy() } catch (_: Exception) {}
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
